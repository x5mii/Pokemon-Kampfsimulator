﻿using PokemonKampf.Models;

namespace PokemonKampf
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var player1Team = await PokemonBattleSimulator.GetRandomPokemonAsync(3);
            var player2Team = await PokemonBattleSimulator.GetRandomPokemonAsync(3);

            Console.WriteLine("Player 1 Team:");
            await DisplayTeamAsync(player1Team);

            Console.WriteLine("\nPlayer 2 Team:");
            await DisplayTeamAsync(player2Team);

            await SimulateBattleAsync(player1Team, player2Team);
        }

        private static async Task DisplayTeamAsync(List<Pokemon> team)
        {
            foreach (var pokemon in team)
            {
                Console.WriteLine($"{pokemon.Name.English} (HP: {pokemon.Base.HP})");
                if (pokemon.Moves != null && pokemon.Moves.Count > 0)
                {
                    var moves = await PokemonBattleSimulator.GetMovesByNamesAsync(pokemon.Moves);
                    Console.WriteLine("Moves:");
                    foreach (var move in moves)
                    {
                        Console.WriteLine($"- {move.Ename} (Power: {move.Power}, Accuracy: {move.Accuracy})");
                    }
                }
                else
                {
                    Console.WriteLine("No moves found for this Pokémon.");
                }
            }
        }

        private static async Task SimulateBattleAsync(List<Pokemon> player1Team, List<Pokemon> player2Team)
        {
            var random = new Random();
            int player1Index = 0;
            int player2Index = 0;

            var player1PokemonMoves = new List<List<Move>>();
            var player2PokemonMoves = new List<List<Move>>();
            foreach (var pokemon in player1Team)
            {
                player1PokemonMoves.Add(await PokemonBattleSimulator.GetMovesByNamesAsync(pokemon.Moves ?? new List<string>()));
            }
            foreach (var pokemon in player2Team)
            {
                player2PokemonMoves.Add(await PokemonBattleSimulator.GetMovesByNamesAsync(pokemon.Moves ?? new List<string>()));
            }

            while (player1Index < player1Team.Count && player2Index < player2Team.Count)
            {
                var player1Pokemon = player1Team[player1Index];
                var player2Pokemon = player2Team[player2Index];

                Console.WriteLine($"\n{player1Pokemon.Name.English} vs {player2Pokemon.Name.English}");

                while (player1Pokemon.Base.HP > 0 && player2Pokemon.Base.HP > 0)
                {
                    if (player1PokemonMoves[player1Index].Count > 0)
                    {
                        var player1Move = player1PokemonMoves[player1Index][random.Next(player1PokemonMoves[player1Index].Count)];
                        int damage = random.Next(10, 20); 
                        player2Pokemon.Base.HP -= damage;
                        Console.WriteLine($"{player1Pokemon.Name.English} uses {player1Move.Ename} on {player2Pokemon.Name.English} for {damage} damage. {player2Pokemon.Name.English} has {player2Pokemon.Base.HP} HP left.");

                        if (player2Pokemon.Base.HP <= 0)
                        {
                            Console.WriteLine($"{player2Pokemon.Name.English} is knocked out!");
                            player2Index++;
                            break;
                        }
                    }

                    if (player2PokemonMoves[player2Index].Count > 0)
                    {
                        var player2Move = player2PokemonMoves[player2Index][random.Next(player2PokemonMoves[player2Index].Count)];
                        int damage = random.Next(10, 20);
                        player1Pokemon.Base.HP -= damage;
                        Console.WriteLine($"{player2Pokemon.Name.English} uses {player2Move.Ename} on {player1Pokemon.Name.English} for {damage} damage. {player1Pokemon.Name.English} has {player1Pokemon.Base.HP} HP left.");

                        if (player1Pokemon.Base.HP <= 0)
                        {
                            Console.WriteLine($"{player1Pokemon.Name.English} is knocked out!");
                            player1Index++;
                            break;
                        }
                    }
                }
            }

            if (player1Index < player1Team.Count)
            {
                Console.WriteLine("\nPlayer 1 wins the battle!");
            }
            else
            {
                Console.WriteLine("\nPlayer 2 wins the battle!");
            }
        }
    }
}
