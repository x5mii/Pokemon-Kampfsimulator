﻿using MongoDB.Bson;
using MongoDB.Driver;
using PokemonKampf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PokemonKampf
{
    public class PokemonBattleSimulator
    {
        private static readonly MongoClient _client = new MongoClient("mongodb://localhost:27017/");
        private static readonly IMongoDatabase _database = _client.GetDatabase("Pokedex");
        private static readonly IMongoCollection<Pokemon> _pokedex = _database.GetCollection<Pokemon>("Pokemons");
        private static readonly IMongoCollection<Move> _moves = _database.GetCollection<Move>("Moves");
        private static readonly IMongoCollection<Item> _items = _database.GetCollection<Item>("Items");
        private static readonly IMongoCollection<PokemonType> _types = _database.GetCollection<PokemonType>("Types");

        public static async Task<List<Pokemon>> GetRandomPokemonAsync(int count)
        {
            var allPokemon = await _pokedex.Find(new BsonDocument()).ToListAsync();
            var random = new Random();
            return allPokemon.OrderBy(x => random.Next()).Take(count).ToList();
        }

        public static async Task<List<Move>> GetMovesByNamesAsync(List<string> moveNames)
        {
            var filter = Builders<Move>.Filter.In(m => m.Ename, moveNames);
            return await _moves.Find(filter).ToListAsync();
        }

        public static async Task<Item> GetItemByNameAsync(string itemName)
        {
            var filter = Builders<Item>.Filter.Eq(i => i.Name.English, itemName);
            return await _items.Find(filter).FirstOrDefaultAsync();
        }
    }
}
