﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace PokemonKampf.Models
{
    public class Pokemon
    {
        [BsonId]
        public ObjectId Id { get; set; }
        public int PokemonId { get; set; }
        public Name Name { get; set; }
        public List<string> Type { get; set; }
        public BaseStats Base { get; set; }
        public List<string> Moves { get; set; }
    }

    public class Name
    {
        public string English { get; set; }
        public string Japanese { get; set; }
        public string Chinese { get; set; }
        public string French { get; set; }
    }

    public class BaseStats
    {
        public int HP { get; set; }
        public int Attack { get; set; }
        public int Defense { get; set; }
        public int SpAttack { get; set; }
        public int SpDefense { get; set; }
        public int Speed { get; set; }
    }

    public class Move
    {
        [BsonId]
        public ObjectId Id { get; set; }
        public int MoveId { get; set; }
        public int Accuracy { get; set; }
        public string Category { get; set; }
        public string Cname { get; set; }
        public string Ename { get; set; }
        public string Jname { get; set; }
        public int Power { get; set; }
        public int PP { get; set; }
        public string Type { get; set; }
    }

    public class Item
    {
        [BsonId]
        public ObjectId Id { get; set; }
        public int ItemId { get; set; }
        public Name Name { get; set; }
    }

    public class PokemonType
    {
        [BsonId]
        public ObjectId Id { get; set; }
        public string English { get; set; }
        public string Chinese { get; set; }
        public string Japanese { get; set; }
    }
}
